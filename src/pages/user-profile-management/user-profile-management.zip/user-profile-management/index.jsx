import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import ProfileHeader from './components/ProfileHeader';
import TabNavigation from './components/TabNavigation';
import PersonalInfoTab from './components/PersonalInfoTab';
import MyPetsTab from './components/MyPetsTab';
import PreferencesTab from './components/PreferencesTab';
import AccountSettingsTab from './components/AccountSettingsTab';
import VerificationModal from './components/VerificationModal';

const UserProfileManagement = () => {
  const [activeTab, setActiveTab] = useState('personal');
  const [showVerificationModal, setShowVerificationModal] = useState(false);

  // Mock user data
  const [userData, setUserData] = useState({
    id: 1,
    name: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    phone: "(555) 123-4567",
    location: "Austin, TX",
    bio: `Passionate dog lover and experienced breeder with over 10 years in the community. I specialize in Golden Retrievers and Labradors, focusing on health, temperament, and quality breeding practices.\n\nI believe in responsible pet ownership and am always happy to share advice with fellow pet enthusiasts. When I'm not with my dogs, you can find me volunteering at the local animal shelter.`,
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
    dateOfBirth: "1985-03-15",
    gender: "female",
    memberSince: "March 2022",
    isVerified: true,
    emailVerified: true,
    phoneVerified: true,
    identityVerified: true,
    addressVerified: false,
    stats: {
      petsListed: 12,
      successfulMatches: 28,
      rating: 4.9
    }
  });

  // Mock pets data
  const [petsData, setPetsData] = useState([
    {
      id: 1,
      name: "Luna",
      breed: "Golden Retriever",
      age: "2 years",
      price: 1200,
      status: "active",
      images: ["https://images.unsplash.com/photo-1552053831-71594a27632d?w=400&h=400&fit=crop"],
      createdAt: "2024-08-20",
      metrics: {
        views: 245,
        favorites: 18,
        messages: 12
      }
    },
    {
      id: 2,
      name: "Max",
      breed: "Labrador",
      age: "3 years",
      price: 1500,
      status: "active",
      images: ["https://images.unsplash.com/photo-1518717758536-85ae29035b6d?w=400&h=400&fit=crop"],
      createdAt: "2024-08-18",
      metrics: {
        views: 189,
        favorites: 24,
        messages: 8
      }
    },
    {
      id: 3,
      name: "Bella",
      breed: "Golden Retriever",
      age: "1 year",
      price: 1800,
      status: "inactive",
      images: ["https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=400&h=400&fit=crop"],
      createdAt: "2024-08-15",
      metrics: {
        views: 156,
        favorites: 15,
        messages: 5
      }
    }
  ]);

  // Mock preferences data
  const [preferencesData, setPreferencesData] = useState({
    matchingPreferences: {
      petTypes: ['Dogs', 'Cats'],
      ageRange: { min: 1, max: 8 },
      distance: 25,
      breedPreferences: ['Golden Retriever', 'Labrador', 'German Shepherd'],
      sizePreferences: ['Medium', 'Large']
    },
    notifications: {
      emailNotifications: true,
      pushNotifications: true,
      smsNotifications: false,
      newMatches: true,
      messages: true,
      petUpdates: true,
      marketingEmails: false
    },
    privacy: {
      profileVisibility: 'public',
      showLocation: true,
      showContactInfo: false,
      allowMessages: 'verified',
      dataSharing: false
    }
  });

  const handleAvatarUpdate = (newAvatarUrl) => {
    setUserData(prev => ({
      ...prev,
      avatar: newAvatarUrl
    }));
  };

  const handlePersonalInfoSave = (formData) => {
    setUserData(prev => ({
      ...prev,
      ...formData
    }));
    alert('Personal information updated successfully!');
  };

  const handlePreferencesSave = (formData) => {
    setPreferencesData(formData);
    alert('Preferences saved successfully!');
  };

  const handleAccountSettingsSave = (formData) => {
    setUserData(prev => ({
      ...prev,
      ...formData
    }));
    alert('Account settings updated successfully!');
  };

  const handleVerificationStart = () => {
    setShowVerificationModal(true);
  };

  const handleVerificationComplete = (verificationData) => {
    setUserData(prev => ({
      ...prev,
      emailVerified: true,
      phoneVerified: true,
      identityVerified: true,
      addressVerified: true,
      isVerified: true
    }));
    alert('Verification completed successfully! Your account is now fully verified.');
  };

  const handleEditPet = (petId) => {
    alert(`Edit pet functionality would open for pet ID: ${petId}`);
  };

  const handleDeletePet = (petId) => {
    if (window.confirm('Are you sure you want to delete this pet listing?')) {
      setPetsData(prev => prev?.filter(pet => pet?.id !== petId));
      alert('Pet listing deleted successfully!');
    }
  };

  const handleTogglePetStatus = (petId) => {
    setPetsData(prev => prev?.map(pet => 
      pet?.id === petId 
        ? { ...pet, status: pet?.status === 'active' ? 'inactive' : 'active' }
        : pet
    ));
  };

  const handleAddPet = () => {
    alert('Add new pet functionality would open here');
  };

  const handleDataExport = () => {
    // Simulate data export
    const exportData = {
      user: userData,
      pets: petsData,
      preferences: preferencesData,
      exportDate: new Date()?.toISOString()
    };
    console.log('Exported data:', exportData);
  };

  const handleAccountDelete = () => {
    if (window.confirm('Are you absolutely sure you want to delete your account? This action cannot be undone.')) {
      alert('Account deletion process initiated. You will receive a confirmation email shortly.');
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'personal':
        return (
          <PersonalInfoTab
            user={userData}
            onSave={handlePersonalInfoSave}
          />
        );
      case 'pets':
        return (
          <MyPetsTab
            pets={petsData}
            onEditPet={handleEditPet}
            onDeletePet={handleDeletePet}
            onToggleStatus={handleTogglePetStatus}
            onAddPet={handleAddPet}
          />
        );
      case 'preferences':
        return (
          <PreferencesTab
            preferences={preferencesData}
            onSave={handlePreferencesSave}
          />
        );
      case 'account':
        return (
          <AccountSettingsTab
            user={userData}
            onSave={handleAccountSettingsSave}
            onVerificationStart={handleVerificationStart}
            onDataExport={handleDataExport}
            onAccountDelete={handleAccountDelete}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Profile Management - PetPair</title>
        <meta name="description" content="Manage your PetPair profile, pets, preferences, and account settings" />
      </Helmet>

      <Header />

      <main className="pt-16">
        <ProfileHeader
          user={userData}
          onAvatarUpdate={handleAvatarUpdate}
          onVerificationStart={handleVerificationStart}
        />

        <TabNavigation
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />

        <div className="px-4 lg:px-6 py-8">
          <div className="max-w-4xl mx-auto">
            {renderTabContent()}
          </div>
        </div>
      </main>

      <VerificationModal
        isOpen={showVerificationModal}
        onClose={() => setShowVerificationModal(false)}
        onComplete={handleVerificationComplete}
      />
    </div>
  );
};

export default UserProfileManagement;