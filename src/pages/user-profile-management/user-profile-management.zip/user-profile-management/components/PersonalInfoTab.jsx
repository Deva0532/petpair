import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const PersonalInfoTab = ({ user, onSave }) => {
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    location: user?.location || '',
    bio: user?.bio || '',
    dateOfBirth: user?.dateOfBirth || '',
    gender: user?.gender || ''
  });
  const [isSaving, setIsSaving] = useState(false);
  const [bioLength, setBioLength] = useState(formData?.bio?.length);

  const genderOptions = [
    { value: 'male', label: 'Male' },
    { value: 'female', label: 'Female' },
    { value: 'other', label: 'Other' },
    { value: 'prefer-not-to-say', label: 'Prefer not to say' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    if (field === 'bio') {
      setBioLength(value?.length);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate save process
    setTimeout(() => {
      if (onSave) {
        onSave(formData);
      }
      setIsSaving(false);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Input
          label="Full Name"
          type="text"
          value={formData?.name}
          onChange={(e) => handleInputChange('name', e?.target?.value)}
          placeholder="Enter your full name"
          required
        />
        
        <Input
          label="Email Address"
          type="email"
          value={formData?.email}
          onChange={(e) => handleInputChange('email', e?.target?.value)}
          placeholder="Enter your email"
          required
        />
        
        <Input
          label="Phone Number"
          type="tel"
          value={formData?.phone}
          onChange={(e) => handleInputChange('phone', e?.target?.value)}
          placeholder="Enter your phone number"
        />
        
        <Input
          label="Date of Birth"
          type="date"
          value={formData?.dateOfBirth}
          onChange={(e) => handleInputChange('dateOfBirth', e?.target?.value)}
        />
        
        <Select
          label="Gender"
          options={genderOptions}
          value={formData?.gender}
          onChange={(value) => handleInputChange('gender', value)}
          placeholder="Select gender"
        />
        
        <Input
          label="Location"
          type="text"
          value={formData?.location}
          onChange={(e) => handleInputChange('location', e?.target?.value)}
          placeholder="City, State"
          required
        />
      </div>
      <div>
        <label className="block text-sm font-body font-medium text-foreground mb-2">
          Bio
        </label>
        <textarea
          value={formData?.bio}
          onChange={(e) => handleInputChange('bio', e?.target?.value)}
          placeholder="Tell others about yourself and your pets..."
          maxLength={500}
          rows={4}
          className="w-full px-3 py-2 border border-border rounded-lg bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
        />
        <div className="flex justify-between items-center mt-2">
          <span className="text-xs text-muted-foreground">
            Share your experience with pets, breeding interests, or what you're looking for
          </span>
          <span className={`text-xs ${bioLength > 450 ? 'text-warning' : 'text-muted-foreground'}`}>
            {bioLength}/500
          </span>
        </div>
      </div>
      <div className="flex justify-end pt-4">
        <Button
          variant="default"
          onClick={handleSave}
          loading={isSaving}
          iconName="Save"
        >
          Save Changes
        </Button>
      </div>
    </div>
  );
};

export default PersonalInfoTab;