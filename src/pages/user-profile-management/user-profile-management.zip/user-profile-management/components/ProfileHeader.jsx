import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ProfileHeader = ({ user, onAvatarUpdate, onVerificationStart }) => {
  const [isUploading, setIsUploading] = useState(false);

  const handleAvatarChange = async (event) => {
    const file = event?.target?.files?.[0];
    if (!file) return;

    setIsUploading(true);
    // Simulate upload process
    setTimeout(() => {
      if (onAvatarUpdate) {
        onAvatarUpdate(URL.createObjectURL(file));
      }
      setIsUploading(false);
    }, 2000);
  };

  return (
    <div className="bg-card border-b border-border">
      <div className="px-4 lg:px-6 py-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          {/* Avatar and Basic Info */}
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className="w-20 h-20 md:w-24 md:h-24 rounded-full overflow-hidden bg-muted">
                <Image
                  src={user?.avatar}
                  alt={user?.name}
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Upload Button */}
              <label className="absolute -bottom-1 -right-1 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center cursor-pointer hover:bg-primary/90 transition-quick shadow-soft">
                <Icon name={isUploading ? "Loader2" : "Camera"} size={16} className={isUploading ? "animate-spin" : ""} />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarChange}
                  className="hidden"
                  disabled={isUploading}
                />
              </label>
              
              {/* Verification Badge */}
              {user?.isVerified && (
                <div className="absolute -top-1 -right-1 w-6 h-6 bg-success text-success-foreground rounded-full flex items-center justify-center">
                  <Icon name="CheckCircle" size={14} />
                </div>
              )}
            </div>
            
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <h1 className="text-xl md:text-2xl font-heading font-bold text-foreground">{user?.name}</h1>
                {!user?.isVerified && (
                  <Button
                    variant="outline"
                    size="xs"
                    iconName="Shield"
                    onClick={onVerificationStart}
                    className="text-xs"
                  >
                    Verify
                  </Button>
                )}
              </div>
              <p className="text-sm text-muted-foreground mt-1">{user?.location}</p>
              <p className="text-xs text-muted-foreground">Member since {user?.memberSince}</p>
            </div>
          </div>
          
          {/* Stats */}
          <div className="flex items-center space-x-6 md:space-x-8">
            <div className="text-center">
              <div className="text-lg md:text-xl font-heading font-bold text-foreground">{user?.stats?.petsListed}</div>
              <div className="text-xs text-muted-foreground">Pets Listed</div>
            </div>
            <div className="text-center">
              <div className="text-lg md:text-xl font-heading font-bold text-foreground">{user?.stats?.successfulMatches}</div>
              <div className="text-xs text-muted-foreground">Matches</div>
            </div>
            <div className="text-center">
              <div className="text-lg md:text-xl font-heading font-bold text-foreground">{user?.stats?.rating}</div>
              <div className="text-xs text-muted-foreground flex items-center justify-center">
                <Icon name="Star" size={12} className="text-warning mr-1" />
                Rating
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;