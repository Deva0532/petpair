import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

import Icon from '../../../components/AppIcon';

const AccountSettingsTab = ({ user, onSave, onVerificationStart, onDataExport, onAccountDelete }) => {
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [emailData, setEmailData] = useState({
    newEmail: user?.email || '',
    password: ''
  });
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [isChangingEmail, setIsChangingEmail] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState('');

  const handlePasswordChange = async () => {
    if (passwordData?.newPassword !== passwordData?.confirmPassword) {
      alert('New passwords do not match');
      return;
    }
    
    setIsChangingPassword(true);
    setTimeout(() => {
      alert('Password changed successfully');
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setIsChangingPassword(false);
    }, 2000);
  };

  const handleEmailChange = async () => {
    setIsChangingEmail(true);
    setTimeout(() => {
      alert('Email change request sent. Please check your new email for verification.');
      setEmailData({ newEmail: '', password: '' });
      setIsChangingEmail(false);
    }, 2000);
  };

  const handleDataExport = async () => {
    setIsExporting(true);
    setTimeout(() => {
      if (onDataExport) {
        onDataExport();
      }
      alert('Your data export has been prepared and will be emailed to you shortly.');
      setIsExporting(false);
    }, 3000);
  };

  const handleAccountDelete = async () => {
    if (deleteConfirmation !== 'DELETE') {
      alert('Please type DELETE to confirm account deletion');
      return;
    }
    
    if (onAccountDelete) {
      onAccountDelete();
    }
  };

  const verificationSteps = [
    { id: 'email', label: 'Email Verification', completed: user?.emailVerified, icon: 'Mail' },
    { id: 'phone', label: 'Phone Verification', completed: user?.phoneVerified, icon: 'Phone' },
    { id: 'identity', label: 'Identity Verification', completed: user?.identityVerified, icon: 'Shield' },
    { id: 'address', label: 'Address Verification', completed: user?.addressVerified, icon: 'MapPin' }
  ];

  return (
    <div className="space-y-8">
      {/* Account Verification */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="ShieldCheck" size={20} className="text-primary" />
          <h3 className="text-lg font-heading font-semibold text-foreground">Account Verification</h3>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center space-x-3 mb-4">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
              user?.isVerified ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'
            }`}>
              <Icon name={user?.isVerified ? 'CheckCircle' : 'Clock'} size={20} />
            </div>
            <div>
              <h4 className="font-body font-medium text-foreground">
                {user?.isVerified ? 'Verified Account' : 'Verification Pending'}
              </h4>
              <p className="text-sm text-muted-foreground">
                {user?.isVerified 
                  ? 'Your account is fully verified and trusted by the community'
                  : 'Complete verification to build trust and unlock all features'
                }
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {verificationSteps?.map((step) => (
              <div
                key={step?.id}
                className={`flex items-center space-x-3 p-3 rounded-lg border ${
                  step?.completed 
                    ? 'border-success/20 bg-success/5' :'border-border bg-muted/30'
                }`}
              >
                <Icon 
                  name={step?.completed ? 'CheckCircle' : step?.icon} 
                  size={16} 
                  className={step?.completed ? 'text-success' : 'text-muted-foreground'} 
                />
                <span className={`text-sm font-body ${
                  step?.completed ? 'text-success' : 'text-muted-foreground'
                }`}>
                  {step?.label}
                </span>
                {step?.completed && (
                  <Icon name="Check" size={14} className="text-success ml-auto" />
                )}
              </div>
            ))}
          </div>
          
          {!user?.isVerified && (
            <Button
              variant="default"
              iconName="Shield"
              onClick={onVerificationStart}
              className="mt-4"
            >
              Start Verification Process
            </Button>
          )}
        </div>
      </div>
      {/* Password Change */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="Lock" size={20} className="text-primary" />
          <h3 className="text-lg font-heading font-semibold text-foreground">Change Password</h3>
        </div>
        
        <div className="space-y-4 max-w-md">
          <Input
            label="Current Password"
            type="password"
            value={passwordData?.currentPassword}
            onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e?.target?.value }))}
            placeholder="Enter current password"
            required
          />
          
          <Input
            label="New Password"
            type="password"
            value={passwordData?.newPassword}
            onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e?.target?.value }))}
            placeholder="Enter new password"
            description="Must be at least 8 characters with numbers and symbols"
            required
          />
          
          <Input
            label="Confirm New Password"
            type="password"
            value={passwordData?.confirmPassword}
            onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e?.target?.value }))}
            placeholder="Confirm new password"
            required
          />
          
          <Button
            variant="default"
            onClick={handlePasswordChange}
            loading={isChangingPassword}
            iconName="Save"
            disabled={!passwordData?.currentPassword || !passwordData?.newPassword || !passwordData?.confirmPassword}
          >
            Change Password
          </Button>
        </div>
      </div>
      {/* Email Change */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="Mail" size={20} className="text-primary" />
          <h3 className="text-lg font-heading font-semibold text-foreground">Change Email Address</h3>
        </div>
        
        <div className="space-y-4 max-w-md">
          <div className="text-sm text-muted-foreground">
            Current email: <span className="font-body font-medium text-foreground">{user?.email}</span>
          </div>
          
          <Input
            label="New Email Address"
            type="email"
            value={emailData?.newEmail}
            onChange={(e) => setEmailData(prev => ({ ...prev, newEmail: e?.target?.value }))}
            placeholder="Enter new email address"
            required
          />
          
          <Input
            label="Password"
            type="password"
            value={emailData?.password}
            onChange={(e) => setEmailData(prev => ({ ...prev, password: e?.target?.value }))}
            placeholder="Enter your password to confirm"
            required
          />
          
          <Button
            variant="default"
            onClick={handleEmailChange}
            loading={isChangingEmail}
            iconName="Save"
            disabled={!emailData?.newEmail || !emailData?.password}
          >
            Change Email
          </Button>
        </div>
      </div>
      {/* Data Export */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="Download" size={20} className="text-primary" />
          <h3 className="text-lg font-heading font-semibold text-foreground">Export Your Data</h3>
        </div>
        
        <p className="text-sm text-muted-foreground mb-4">
          Download a copy of all your data including profile information, pet listings, messages, and activity history.
        </p>
        
        <Button
          variant="outline"
          onClick={handleDataExport}
          loading={isExporting}
          iconName="Download"
        >
          {isExporting ? 'Preparing Export...' : 'Export My Data'}
        </Button>
      </div>
      {/* Account Deletion */}
      <div className="bg-card border border-error/20 rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="AlertTriangle" size={20} className="text-error" />
          <h3 className="text-lg font-heading font-semibold text-error">Delete Account</h3>
        </div>
        
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Permanently delete your account and all associated data. This action cannot be undone.
          </p>
          
          <div className="bg-error/5 border border-error/20 rounded-lg p-4">
            <h4 className="font-body font-medium text-error mb-2">What will be deleted:</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Your profile and account information</li>
              <li>• All pet listings and photos</li>
              <li>• Message history and conversations</li>
              <li>• Favorites and match history</li>
              <li>• Reviews and ratings</li>
            </ul>
          </div>
          
          {!showDeleteConfirm ? (
            <Button
              variant="destructive"
              onClick={() => setShowDeleteConfirm(true)}
              iconName="Trash2"
            >
              Delete My Account
            </Button>
          ) : (
            <div className="space-y-4 max-w-md">
              <Input
                label="Type 'DELETE' to confirm"
                type="text"
                value={deleteConfirmation}
                onChange={(e) => setDeleteConfirmation(e?.target?.value)}
                placeholder="DELETE"
                description="This action is permanent and cannot be undone"
              />
              
              <div className="flex space-x-3">
                <Button
                  variant="destructive"
                  onClick={handleAccountDelete}
                  disabled={deleteConfirmation !== 'DELETE'}
                  iconName="Trash2"
                >
                  Permanently Delete Account
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowDeleteConfirm(false);
                    setDeleteConfirmation('');
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AccountSettingsTab;