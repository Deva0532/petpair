import React, { useState } from 'react';
import { Checkbox } from '../../../components/ui/Checkbox';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const PreferencesTab = ({ preferences, onSave }) => {
  const [formData, setFormData] = useState({
    matchingPreferences: {
      petTypes: preferences?.matchingPreferences?.petTypes || [],
      ageRange: preferences?.matchingPreferences?.ageRange || { min: 0, max: 15 },
      distance: preferences?.matchingPreferences?.distance || 25,
      breedPreferences: preferences?.matchingPreferences?.breedPreferences || [],
      sizePreferences: preferences?.matchingPreferences?.sizePreferences || []
    },
    notifications: {
      emailNotifications: preferences?.notifications?.emailNotifications || true,
      pushNotifications: preferences?.notifications?.pushNotifications || true,
      smsNotifications: preferences?.notifications?.smsNotifications || false,
      newMatches: preferences?.notifications?.newMatches || true,
      messages: preferences?.notifications?.messages || true,
      petUpdates: preferences?.notifications?.petUpdates || true,
      marketingEmails: preferences?.notifications?.marketingEmails || false
    },
    privacy: {
      profileVisibility: preferences?.privacy?.profileVisibility || 'public',
      showLocation: preferences?.privacy?.showLocation || true,
      showContactInfo: preferences?.privacy?.showContactInfo || false,
      allowMessages: preferences?.privacy?.allowMessages || 'verified',
      dataSharing: preferences?.privacy?.dataSharing || false
    }
  });
  const [isSaving, setIsSaving] = useState(false);

  const petTypeOptions = [
    'Dogs', 'Cats', 'Birds', 'Rabbits', 'Fish', 'Reptiles', 'Small Mammals', 'Farm Animals'
  ];

  const breedOptions = [
    'Golden Retriever', 'Labrador', 'German Shepherd', 'Bulldog', 'Poodle',
    'Persian Cat', 'Siamese Cat', 'Maine Coon', 'British Shorthair'
  ];

  const sizeOptions = ['Small', 'Medium', 'Large', 'Extra Large'];

  const distanceOptions = [
    { value: 5, label: '5 miles' },
    { value: 10, label: '10 miles' },
    { value: 25, label: '25 miles' },
    { value: 50, label: '50 miles' },
    { value: 100, label: '100 miles' },
    { value: 500, label: 'Any distance' }
  ];

  const visibilityOptions = [
    { value: 'public', label: 'Public - Anyone can see' },
    { value: 'verified', label: 'Verified users only' },
    { value: 'private', label: 'Private - Hidden from search' }
  ];

  const messageOptions = [
    { value: 'anyone', label: 'Anyone can message me' },
    { value: 'verified', label: 'Only verified users' },
    { value: 'matches', label: 'Only my matches' },
    { value: 'none', label: 'No one can message me' }
  ];

  const handlePetTypeToggle = (petType) => {
    setFormData(prev => ({
      ...prev,
      matchingPreferences: {
        ...prev?.matchingPreferences,
        petTypes: prev?.matchingPreferences?.petTypes?.includes(petType)
          ? prev?.matchingPreferences?.petTypes?.filter(type => type !== petType)
          : [...prev?.matchingPreferences?.petTypes, petType]
      }
    }));
  };

  const handleBreedToggle = (breed) => {
    setFormData(prev => ({
      ...prev,
      matchingPreferences: {
        ...prev?.matchingPreferences,
        breedPreferences: prev?.matchingPreferences?.breedPreferences?.includes(breed)
          ? prev?.matchingPreferences?.breedPreferences?.filter(b => b !== breed)
          : [...prev?.matchingPreferences?.breedPreferences, breed]
      }
    }));
  };

  const handleSizeToggle = (size) => {
    setFormData(prev => ({
      ...prev,
      matchingPreferences: {
        ...prev?.matchingPreferences,
        sizePreferences: prev?.matchingPreferences?.sizePreferences?.includes(size)
          ? prev?.matchingPreferences?.sizePreferences?.filter(s => s !== size)
          : [...prev?.matchingPreferences?.sizePreferences, size]
      }
    }));
  };

  const handleNotificationToggle = (key) => {
    setFormData(prev => ({
      ...prev,
      notifications: {
        ...prev?.notifications,
        [key]: !prev?.notifications?.[key]
      }
    }));
  };

  const handlePrivacyToggle = (key) => {
    setFormData(prev => ({
      ...prev,
      privacy: {
        ...prev?.privacy,
        [key]: !prev?.privacy?.[key]
      }
    }));
  };

  const handleSelectChange = (section, key, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev?.[section],
        [key]: value
      }
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    setTimeout(() => {
      if (onSave) {
        onSave(formData);
      }
      setIsSaving(false);
    }, 1500);
  };

  return (
    <div className="space-y-8">
      {/* Matching Preferences */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="Heart" size={20} className="text-primary" />
          <h3 className="text-lg font-heading font-semibold text-foreground">Matching Preferences</h3>
        </div>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-body font-medium text-foreground mb-3">
              Interested Pet Types
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {petTypeOptions?.map((petType) => (
                <Checkbox
                  key={petType}
                  label={petType}
                  checked={formData?.matchingPreferences?.petTypes?.includes(petType)}
                  onChange={() => handlePetTypeToggle(petType)}
                />
              ))}
            </div>
          </div>
          
          <div>
            <Select
              label="Maximum Distance"
              options={distanceOptions}
              value={formData?.matchingPreferences?.distance}
              onChange={(value) => handleSelectChange('matchingPreferences', 'distance', value)}
            />
          </div>
          
          <div>
            <label className="block text-sm font-body font-medium text-foreground mb-3">
              Preferred Breeds
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {breedOptions?.map((breed) => (
                <Checkbox
                  key={breed}
                  label={breed}
                  checked={formData?.matchingPreferences?.breedPreferences?.includes(breed)}
                  onChange={() => handleBreedToggle(breed)}
                />
              ))}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-body font-medium text-foreground mb-3">
              Preferred Sizes
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {sizeOptions?.map((size) => (
                <Checkbox
                  key={size}
                  label={size}
                  checked={formData?.matchingPreferences?.sizePreferences?.includes(size)}
                  onChange={() => handleSizeToggle(size)}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
      {/* Notification Settings */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="Bell" size={20} className="text-primary" />
          <h3 className="text-lg font-heading font-semibold text-foreground">Notification Settings</h3>
        </div>
        
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="text-sm font-body font-medium text-foreground">Notification Methods</h4>
              <Checkbox
                label="Email Notifications"
                description="Receive notifications via email"
                checked={formData?.notifications?.emailNotifications}
                onChange={() => handleNotificationToggle('emailNotifications')}
              />
              <Checkbox
                label="Push Notifications"
                description="Browser and mobile push notifications"
                checked={formData?.notifications?.pushNotifications}
                onChange={() => handleNotificationToggle('pushNotifications')}
              />
              <Checkbox
                label="SMS Notifications"
                description="Text message notifications for urgent updates"
                checked={formData?.notifications?.smsNotifications}
                onChange={() => handleNotificationToggle('smsNotifications')}
              />
            </div>
            
            <div className="space-y-4">
              <h4 className="text-sm font-body font-medium text-foreground">Notification Types</h4>
              <Checkbox
                label="New Matches"
                description="When someone likes your pet"
                checked={formData?.notifications?.newMatches}
                onChange={() => handleNotificationToggle('newMatches')}
              />
              <Checkbox
                label="Messages"
                description="New messages from other users"
                checked={formData?.notifications?.messages}
                onChange={() => handleNotificationToggle('messages')}
              />
              <Checkbox
                label="Pet Updates"
                description="Updates about your listed pets"
                checked={formData?.notifications?.petUpdates}
                onChange={() => handleNotificationToggle('petUpdates')}
              />
              <Checkbox
                label="Marketing Emails"
                description="Tips, news, and promotional content"
                checked={formData?.notifications?.marketingEmails}
                onChange={() => handleNotificationToggle('marketingEmails')}
              />
            </div>
          </div>
        </div>
      </div>
      {/* Privacy Settings */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="Shield" size={20} className="text-primary" />
          <h3 className="text-lg font-heading font-semibold text-foreground">Privacy Settings</h3>
        </div>
        
        <div className="space-y-6">
          <Select
            label="Profile Visibility"
            description="Control who can see your profile"
            options={visibilityOptions}
            value={formData?.privacy?.profileVisibility}
            onChange={(value) => handleSelectChange('privacy', 'profileVisibility', value)}
          />
          
          <Select
            label="Who Can Message Me"
            description="Control who can send you messages"
            options={messageOptions}
            value={formData?.privacy?.allowMessages}
            onChange={(value) => handleSelectChange('privacy', 'allowMessages', value)}
          />
          
          <div className="space-y-4">
            <Checkbox
              label="Show My Location"
              description="Display your city and state on your profile"
              checked={formData?.privacy?.showLocation}
              onChange={() => handlePrivacyToggle('showLocation')}
            />
            <Checkbox
              label="Show Contact Information"
              description="Allow verified users to see your contact details"
              checked={formData?.privacy?.showContactInfo}
              onChange={() => handlePrivacyToggle('showContactInfo')}
            />
            <Checkbox
              label="Allow Data Sharing"
              description="Share anonymized data to improve matching algorithms"
              checked={formData?.privacy?.dataSharing}
              onChange={() => handlePrivacyToggle('dataSharing')}
            />
          </div>
        </div>
      </div>
      <div className="flex justify-end pt-4">
        <Button
          variant="default"
          onClick={handleSave}
          loading={isSaving}
          iconName="Save"
        >
          Save Preferences
        </Button>
      </div>
    </div>
  );
};

export default PreferencesTab;