import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const MyPetsTab = ({ pets, onEditPet, onDeletePet, onToggleStatus, onAddPet }) => {
  const [viewMode, setViewMode] = useState('grid');
  const [sortBy, setSortBy] = useState('recent');

  const sortOptions = [
    { value: 'recent', label: 'Most Recent' },
    { value: 'views', label: 'Most Viewed' },
    { value: 'favorites', label: 'Most Favorited' },
    { value: 'messages', label: 'Most Messages' },
    { value: 'alphabetical', label: 'Alphabetical' }
  ];

  const viewModeOptions = [
    { value: 'grid', label: 'Grid View', icon: 'Grid3X3' },
    { value: 'list', label: 'List View', icon: 'List' }
  ];

  const sortedPets = [...pets]?.sort((a, b) => {
    switch (sortBy) {
      case 'views':
        return b?.metrics?.views - a?.metrics?.views;
      case 'favorites':
        return b?.metrics?.favorites - a?.metrics?.favorites;
      case 'messages':
        return b?.metrics?.messages - a?.metrics?.messages;
      case 'alphabetical':
        return a?.name?.localeCompare(b?.name);
      default:
        return new Date(b.createdAt) - new Date(a.createdAt);
    }
  });

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div className="flex items-center space-x-4">
          <h2 className="text-lg font-heading font-semibold text-foreground">
            My Pets ({pets?.length})
          </h2>
          <Button
            variant="default"
            size="sm"
            iconName="Plus"
            onClick={onAddPet}
          >
            Add Pet
          </Button>
        </div>
        
        <div className="flex items-center space-x-3">
          <Select
            options={sortOptions}
            value={sortBy}
            onChange={setSortBy}
            className="w-40"
          />
          
          <div className="flex bg-muted rounded-lg p-1">
            {viewModeOptions?.map((option) => (
              <button
                key={option?.value}
                onClick={() => setViewMode(option?.value)}
                className={`flex items-center space-x-1 px-3 py-1 rounded-md text-sm transition-quick ${
                  viewMode === option?.value
                    ? 'bg-card text-foreground shadow-soft'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon name={option?.icon} size={14} />
                <span className="hidden sm:inline">{option?.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
      {/* Pets Grid/List */}
      {sortedPets?.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="Heart" size={24} className="text-muted-foreground" />
          </div>
          <h3 className="text-lg font-heading font-semibold text-foreground mb-2">No pets listed yet</h3>
          <p className="text-muted-foreground mb-4">Start by adding your first pet to the marketplace</p>
          <Button variant="default" iconName="Plus" onClick={onAddPet}>
            Add Your First Pet
          </Button>
        </div>
      ) : (
        <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}>
          {sortedPets?.map((pet) => (
            <PetCard
              key={pet?.id}
              pet={pet}
              viewMode={viewMode}
              onEdit={() => onEditPet(pet?.id)}
              onDelete={() => onDeletePet(pet?.id)}
              onToggleStatus={() => onToggleStatus(pet?.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const PetCard = ({ pet, viewMode, onEdit, onDelete, onToggleStatus }) => {
  const [showActions, setShowActions] = useState(false);

  if (viewMode === 'list') {
    return (
      <div className="bg-card border border-border rounded-lg p-4 hover:shadow-soft transition-quick">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 rounded-lg overflow-hidden bg-muted flex-shrink-0">
            <Image
              src={pet?.images?.[0]}
              alt={pet?.name}
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2">
              <h3 className="text-base font-heading font-semibold text-foreground truncate">{pet?.name}</h3>
              <span className={`px-2 py-1 text-xs font-body font-medium rounded-full ${
                pet?.status === 'active' ?'bg-success/10 text-success' :'bg-muted text-muted-foreground'
              }`}>
                {pet?.status}
              </span>
            </div>
            <p className="text-sm text-muted-foreground">{pet?.breed} • {pet?.age} • ${pet?.price}</p>
            
            <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
              <span className="flex items-center space-x-1">
                <Icon name="Eye" size={12} />
                <span>{pet?.metrics?.views}</span>
              </span>
              <span className="flex items-center space-x-1">
                <Icon name="Heart" size={12} />
                <span>{pet?.metrics?.favorites}</span>
              </span>
              <span className="flex items-center space-x-1">
                <Icon name="MessageCircle" size={12} />
                <span>{pet?.metrics?.messages}</span>
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" iconName="Edit" onClick={onEdit} />
            <Button variant="ghost" size="sm" iconName="MoreVertical" onClick={() => setShowActions(!showActions)} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden hover:shadow-soft transition-quick">
      <div className="relative">
        <div className="aspect-square bg-muted">
          <Image
            src={pet?.images?.[0]}
            alt={pet?.name}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="absolute top-2 right-2 flex space-x-1">
          <span className={`px-2 py-1 text-xs font-body font-medium rounded-full backdrop-blur-sm ${
            pet?.status === 'active' ?'bg-success/90 text-white' :'bg-muted/90 text-muted-foreground'
          }`}>
            {pet?.status}
          </span>
        </div>
        
        <div className="absolute top-2 left-2">
          <button
            onClick={onToggleStatus}
            className={`w-8 h-8 rounded-full backdrop-blur-sm flex items-center justify-center transition-quick ${
              pet?.status === 'active' ?'bg-success/90 text-white hover:bg-success' :'bg-muted/90 text-muted-foreground hover:bg-muted'
            }`}
          >
            <Icon name={pet?.status === 'active' ? 'Eye' : 'EyeOff'} size={14} />
          </button>
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div>
            <h3 className="text-base font-heading font-semibold text-foreground">{pet?.name}</h3>
            <p className="text-sm text-muted-foreground">{pet?.breed} • {pet?.age}</p>
          </div>
          <span className="text-lg font-heading font-bold text-primary">${pet?.price}</span>
        </div>
        
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
          <span className="flex items-center space-x-1">
            <Icon name="Eye" size={12} />
            <span>{pet?.metrics?.views}</span>
          </span>
          <span className="flex items-center space-x-1">
            <Icon name="Heart" size={12} />
            <span>{pet?.metrics?.favorites}</span>
          </span>
          <span className="flex items-center space-x-1">
            <Icon name="MessageCircle" size={12} />
            <span>{pet?.metrics?.messages}</span>
          </span>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" iconName="Edit" onClick={onEdit} className="flex-1">
            Edit
          </Button>
          <Button variant="ghost" size="sm" iconName="Trash2" onClick={onDelete} className="text-error hover:text-error">
            Delete
          </Button>
        </div>
      </div>
    </div>
  );
};

export default MyPetsTab;