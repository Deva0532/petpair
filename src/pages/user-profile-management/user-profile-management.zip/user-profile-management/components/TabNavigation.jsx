import React from 'react';
import Icon from '../../../components/AppIcon';

const TabNavigation = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'personal', label: 'Personal Info', icon: 'User' },
    { id: 'pets', label: 'My Pets', icon: 'Heart' },
    { id: 'preferences', label: 'Preferences', icon: 'Settings' },
    { id: 'account', label: 'Account', icon: 'Shield' }
  ];

  return (
    <div className="bg-card border-b border-border">
      <div className="px-4 lg:px-6">
        <nav className="flex space-x-1 overflow-x-auto">
          {tabs?.map((tab) => (
            <button
              key={tab?.id}
              onClick={() => onTabChange(tab?.id)}
              className={`flex items-center space-x-2 px-4 py-3 text-sm font-body font-medium whitespace-nowrap transition-quick ${
                activeTab === tab?.id
                  ? 'text-primary border-b-2 border-primary' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon name={tab?.icon} size={16} />
              <span className="hidden sm:inline">{tab?.label}</span>
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default TabNavigation;