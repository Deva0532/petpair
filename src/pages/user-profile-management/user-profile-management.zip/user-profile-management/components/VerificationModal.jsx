import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';

const VerificationModal = ({ isOpen, onClose, onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    email: '',
    phone: '',
    idType: 'drivers_license',
    idNumber: '',
    address: '',
    city: '',
    state: '',
    zipCode: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const steps = [
    {
      id: 'email',
      title: 'Email Verification',
      description: 'Verify your email address to secure your account',
      icon: 'Mail'
    },
    {
      id: 'phone',
      title: 'Phone Verification',
      description: 'Add your phone number for account security',
      icon: 'Phone'
    },
    {
      id: 'identity',
      title: 'Identity Verification',
      description: 'Verify your identity with a government-issued ID',
      icon: 'Shield'
    },
    {
      id: 'address',
      title: 'Address Verification',
      description: 'Confirm your address for location-based matching',
      icon: 'MapPin'
    }
  ];

  const idTypeOptions = [
    { value: 'drivers_license', label: "Driver\'s License" },
    { value: 'passport', label: 'Passport' },
    { value: 'state_id', label: 'State ID' },
    { value: 'military_id', label: 'Military ID' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleNext = () => {
    if (currentStep < steps?.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleSubmit();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setTimeout(() => {
      if (onComplete) {
        onComplete(formData);
      }
      setIsSubmitting(false);
      onClose();
    }, 2000);
  };

  if (!isOpen) return null;

  const currentStepData = steps?.[currentStep];

  return (
    <div className="fixed inset-0 z-150 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-card border border-border rounded-lg shadow-floating w-full max-w-md mx-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
              <Icon name={currentStepData?.icon} size={20} className="text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-heading font-semibold text-foreground">
                {currentStepData?.title}
              </h2>
              <p className="text-sm text-muted-foreground">
                Step {currentStep + 1} of {steps?.length}
              </p>
            </div>
          </div>
          <Button variant="ghost" size="sm" iconName="X" onClick={onClose} />
        </div>

        {/* Progress Bar */}
        <div className="px-6 py-4">
          <div className="flex items-center space-x-2">
            {steps?.map((step, index) => (
              <React.Fragment key={step?.id}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  index <= currentStep 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-muted text-muted-foreground'
                }`}>
                  {index < currentStep ? (
                    <Icon name="Check" size={14} />
                  ) : (
                    index + 1
                  )}
                </div>
                {index < steps?.length - 1 && (
                  <div className={`flex-1 h-1 rounded ${
                    index < currentStep ? 'bg-primary' : 'bg-muted'
                  }`} />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="px-6 pb-6">
          <p className="text-sm text-muted-foreground mb-6">
            {currentStepData?.description}
          </p>

          <div className="space-y-4">
            {currentStep === 0 && (
              <div>
                <Input
                  label="Email Address"
                  type="email"
                  value={formData?.email}
                  onChange={(e) => handleInputChange('email', e?.target?.value)}
                  placeholder="Enter your email address"
                  required
                />
                <p className="text-xs text-muted-foreground mt-2">
                  We'll send a verification code to this email address
                </p>
              </div>
            )}

            {currentStep === 1 && (
              <div>
                <Input
                  label="Phone Number"
                  type="tel"
                  value={formData?.phone}
                  onChange={(e) => handleInputChange('phone', e?.target?.value)}
                  placeholder="(555) 123-4567"
                  required
                />
                <p className="text-xs text-muted-foreground mt-2">
                  We'll send a verification code via SMS
                </p>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-body font-medium text-foreground mb-2">
                    ID Type
                  </label>
                  <select
                    value={formData?.idType}
                    onChange={(e) => handleInputChange('idType', e?.target?.value)}
                    className="w-full px-3 py-2 border border-border rounded-lg bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    {idTypeOptions?.map((option) => (
                      <option key={option?.value} value={option?.value}>
                        {option?.label}
                      </option>
                    ))}
                  </select>
                </div>
                
                <Input
                  label="ID Number"
                  type="text"
                  value={formData?.idNumber}
                  onChange={(e) => handleInputChange('idNumber', e?.target?.value)}
                  placeholder="Enter your ID number"
                  required
                />
                
                <div className="bg-muted/50 border border-border rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <Icon name="Shield" size={16} className="text-primary mt-0.5" />
                    <div>
                      <h4 className="text-sm font-body font-medium text-foreground">Secure Verification</h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        Your ID information is encrypted and only used for verification purposes. 
                        We never store or share your ID details.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-4">
                <Input
                  label="Street Address"
                  type="text"
                  value={formData?.address}
                  onChange={(e) => handleInputChange('address', e?.target?.value)}
                  placeholder="123 Main Street"
                  required
                />
                
                <div className="grid grid-cols-2 gap-3">
                  <Input
                    label="City"
                    type="text"
                    value={formData?.city}
                    onChange={(e) => handleInputChange('city', e?.target?.value)}
                    placeholder="City"
                    required
                  />
                  <Input
                    label="State"
                    type="text"
                    value={formData?.state}
                    onChange={(e) => handleInputChange('state', e?.target?.value)}
                    placeholder="State"
                    required
                  />
                </div>
                
                <Input
                  label="ZIP Code"
                  type="text"
                  value={formData?.zipCode}
                  onChange={(e) => handleInputChange('zipCode', e?.target?.value)}
                  placeholder="12345"
                  required
                />
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-border">
          <Button
            variant="outline"
            onClick={currentStep === 0 ? onClose : handleBack}
            disabled={isSubmitting}
          >
            {currentStep === 0 ? 'Cancel' : 'Back'}
          </Button>
          
          <Button
            variant="default"
            onClick={handleNext}
            loading={isSubmitting}
            iconName={currentStep === steps?.length - 1 ? 'Check' : 'ArrowRight'}
          >
            {currentStep === steps?.length - 1 ? 'Complete Verification' : 'Next'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VerificationModal;