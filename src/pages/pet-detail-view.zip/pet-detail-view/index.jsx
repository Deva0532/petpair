import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

// Import all components
import ImageGallery from './components/ImageGallery';
import PetInfoCard from './components/PetInfoCard';
import OwnerProfileCard from './components/OwnerProfileCard';
import HealthRecordsCard from './components/HealthRecordsCard';
import LocationMap from './components/LocationMap';
import RelatedPetsCarousel from './components/RelatedPetsCarousel';
import ActionButtons from './components/ActionButtons';

const PetDetailView = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [pet, setPet] = useState(null);
  const [isFavorited, setIsFavorited] = useState(false);

  // Mock data for the pet detail
  const mockPetData = {
    id: "pet-001",
    name: "Luna",
    breed: "Golden Retriever",
    age: "2 years old",
    gender: "Female",
    size: "Large",
    weight: "65 lbs",
    color: "Golden",
    location: "San Francisco, CA",
    price: 1200,
    isForBreeding: false,
    breedingFee: null,
    description: `Luna is a beautiful and gentle Golden Retriever who loves to play fetch and swim. She's great with children and other pets, making her the perfect family companion. Luna is house-trained, knows basic commands, and has a calm, loving temperament.\n\nShe enjoys long walks in the park and loves to cuddle on the couch after a day of play. Luna would thrive in a home with a yard where she can run and play freely.`,
    traits: [
      "Good with kids",
      "Good with pets", 
      "House trained",
      "Vaccinated",
      "Spayed",
      "Microchipped",
      "Friendly",
      "Active",
      "Playful"
    ],
    healthStatus: "Excellent health",
    images: [
      "https://images.unsplash.com/photo-1552053831-71594a27632d?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1605568427561-40dd23c2acea?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=800&h=600&fit=crop"
    ],
    owner: {
      id: "owner-001",
      name: "Sarah Johnson",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      isVerified: true,
      rating: 4.8,
      totalReviews: 24,
      memberSince: "2021",
      location: "San Francisco, CA",
      totalPets: 3,
      responseTime: "Usually responds within 2 hours",
      bio: "Passionate dog lover and responsible breeder. I've been raising Golden Retrievers for over 8 years and ensure all my pets go to loving homes."
    },
    healthRecords: {
      vaccinations: [
        {
          name: "DHPP (Distemper, Hepatitis, Parvovirus, Parainfluenza)",date: "2024-06-15",nextDue: "2025-06-15"
        },
        {
          name: "Rabies",date: "2024-06-15", nextDue: "2027-06-15"
        },
        {
          name: "Bordetella",date: "2024-08-01",nextDue: "2025-08-01"
        }
      ],
      medicalHistory: [
        {
          condition: "Routine Health Check",description: "Annual wellness exam - all vitals normal, excellent health",date: "2024-08-15"
        },
        {
          condition: "Spay Surgery",description: "Successful spay procedure with no complications",date: "2023-03-20"
        }
      ],
      veterinarian: {
        name: "Dr. Michael Chen",clinic: "Bay Area Animal Hospital",phone: "(415) 555-0123"
      },
      lastCheckup: "2024-08-15",
      spayedNeutered: true,
      microchipped: true,
      healthCertificate: true,
      specialNeeds: [],
      medications: []
    },
    locationData: {
      city: "San Francisco",state: "CA",zipCode: "94102",
      latitude: 37.7749,
      longitude: -122.4194,
      showExactLocation: false
    }
  };

  // Mock related pets data
  const mockRelatedPets = [
    {
      id: "pet-002",
      name: "Max",
      breed: "Golden Retriever",
      age: "3 years old",
      price: 1500,
      isForBreeding: false,
      images: ["https://images.unsplash.com/photo-1551717743-49959800b1f6?w=300&h=200&fit=crop"],
      location: "Oakland, CA",
      isFavorited: false
    },
    {
      id: "pet-003", 
      name: "Bella",
      breed: "Labrador Retriever",
      age: "1 year old",
      price: 1000,
      isForBreeding: false,
      images: ["https://images.unsplash.com/photo-1518717758536-85ae29035b6d?w=300&h=200&fit=crop"],
      location: "San Jose, CA",
      isFavorited: true
    },
    {
      id: "pet-004",
      name: "Charlie",
      breed: "Golden Retriever",
      age: "4 years old",
      breedingFee: 800,
      isForBreeding: true,
      images: ["https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=300&h=200&fit=crop"],
      location: "Berkeley, CA",
      isFavorited: false
    },
    {
      id: "pet-005",
      name: "Daisy",
      breed: "Labrador Mix",
      age: "2 years old",
      price: 900,
      isForBreeding: false,
      images: ["https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=300&h=200&fit=crop"],
      location: "Palo Alto, CA",
      isFavorited: false
    }
  ];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setPet(mockPetData);
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const handleFavoriteToggle = () => {
    setIsFavorited(!isFavorited);
  };

  const handleBackNavigation = () => {
    navigate(-1);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-16">
          <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
            {/* Loading Skeleton */}
            <div className="animate-pulse space-y-6">
              {/* Breadcrumb Skeleton */}
              <div className="h-4 bg-muted rounded w-64" />
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Image Gallery Skeleton */}
                <div className="space-y-4">
                  <div className="h-80 bg-muted rounded-lg" />
                  <div className="flex space-x-2">
                    {[1, 2, 3, 4]?.map((i) => (
                      <div key={i} className="w-16 h-16 bg-muted rounded-lg" />
                    ))}
                  </div>
                </div>
                
                {/* Info Skeleton */}
                <div className="space-y-6">
                  <div className="h-32 bg-muted rounded-lg" />
                  <div className="h-48 bg-muted rounded-lg" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!pet) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-16">
          <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
            <div className="text-center py-16">
              <Icon name="AlertCircle" size={48} className="text-muted-foreground mx-auto mb-4" />
              <h2 className="text-xl font-heading font-semibold text-foreground mb-2">Pet Not Found</h2>
              <p className="text-muted-foreground mb-6">The pet you're looking for doesn't exist or has been removed.</p>
              <Button variant="default" onClick={() => navigate('/main-dashboard-sell-date-toggle')}>
                Back to Browse
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Header />
      <div className="pt-16">
        <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
          {/* Breadcrumb Navigation */}
          <nav className="flex items-center space-x-2 text-sm text-muted-foreground mb-6">
            <Link 
              to="/main-dashboard-sell-date-toggle" 
              className="hover:text-foreground transition-colors"
            >
              Browse Pets
            </Link>
            <Icon name="ChevronRight" size={16} />
            <span className="text-foreground">{pet?.name}</span>
          </nav>

          {/* Back Button - Mobile */}
          <div className="md:hidden mb-4">
            <Button
              variant="ghost"
              size="sm"
              iconName="ArrowLeft"
              iconPosition="left"
              onClick={handleBackNavigation}
            >
              Back
            </Button>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Left Column - Images */}
            <div>
              <ImageGallery images={pet?.images} petName={pet?.name} />
            </div>

            {/* Right Column - Pet Info & Owner */}
            <div className="space-y-6">
              <PetInfoCard pet={pet} />
              <OwnerProfileCard owner={pet?.owner} />
            </div>
          </div>

          {/* Additional Information */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <HealthRecordsCard healthRecords={pet?.healthRecords} />
            <LocationMap location={pet?.locationData} />
          </div>

          {/* Related Pets */}
          <div className="mb-8">
            <RelatedPetsCarousel relatedPets={mockRelatedPets} />
          </div>

          {/* Action Buttons */}
          <ActionButtons 
            petId={pet?.id}
            isFavorited={isFavorited}
            onFavoriteToggle={handleFavoriteToggle}
          />
        </div>
      </div>
    </div>
  );
};

export default PetDetailView;