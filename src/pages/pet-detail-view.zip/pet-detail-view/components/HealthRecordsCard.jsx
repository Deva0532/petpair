import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const HealthRecordsCard = ({ healthRecords = {} }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const {
    vaccinations = [],
    medicalHistory = [],
    veterinarian = null,
    lastCheckup = null,
    spayedNeutered = false,
    microchipped = false,
    healthCertificate = false,
    specialNeeds = [],
    medications = []
  } = healthRecords;

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  const formatDate = (dateString) => {
    if (!dateString) return "Not recorded";
    return new Date(dateString)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusIcon = (status) => {
    return status ? "CheckCircle" : "XCircle";
  };

  const getStatusColor = (status) => {
    return status ? "text-success" : "text-muted-foreground";
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Icon name="Heart" size={20} className="text-accent" />
          <h3 className="font-heading font-semibold text-foreground">Health Records</h3>
        </div>
        <Button
          variant="ghost"
          size="sm"
          iconName={isExpanded ? "ChevronUp" : "ChevronDown"}
          onClick={toggleExpanded}
        >
          {isExpanded ? "Show Less" : "Show More"}
        </Button>
      </div>
      {/* Quick Health Status */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="flex items-center space-x-2">
          <Icon 
            name={getStatusIcon(spayedNeutered)} 
            size={16} 
            className={getStatusColor(spayedNeutered)} 
          />
          <div>
            <p className="text-xs text-muted-foreground">Spayed/Neutered</p>
            <p className="text-sm font-medium">{spayedNeutered ? "Yes" : "No"}</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Icon 
            name={getStatusIcon(microchipped)} 
            size={16} 
            className={getStatusColor(microchipped)} 
          />
          <div>
            <p className="text-xs text-muted-foreground">Microchipped</p>
            <p className="text-sm font-medium">{microchipped ? "Yes" : "No"}</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Icon 
            name={getStatusIcon(healthCertificate)} 
            size={16} 
            className={getStatusColor(healthCertificate)} 
          />
          <div>
            <p className="text-xs text-muted-foreground">Health Certificate</p>
            <p className="text-sm font-medium">{healthCertificate ? "Available" : "Not Available"}</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Icon name="Calendar" size={16} className="text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground">Last Checkup</p>
            <p className="text-sm font-medium">{formatDate(lastCheckup)}</p>
          </div>
        </div>
      </div>
      {/* Expanded Content */}
      {isExpanded && (
        <div className="space-y-6 pt-4 border-t border-border">
          {/* Vaccinations */}
          {vaccinations?.length > 0 && (
            <div>
              <h4 className="font-medium text-foreground mb-3 flex items-center space-x-2">
                <Icon name="Shield" size={16} className="text-success" />
                <span>Vaccinations</span>
              </h4>
              <div className="space-y-2">
                {vaccinations?.map((vaccination, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{vaccination?.name}</p>
                      <p className="text-xs text-muted-foreground">
                        Next due: {formatDate(vaccination?.nextDue)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{formatDate(vaccination?.date)}</p>
                      <div className="flex items-center space-x-1">
                        <Icon name="CheckCircle" size={12} className="text-success" />
                        <span className="text-xs text-success">Up to date</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Medical History */}
          {medicalHistory?.length > 0 && (
            <div>
              <h4 className="font-medium text-foreground mb-3 flex items-center space-x-2">
                <Icon name="FileText" size={16} className="text-primary" />
                <span>Medical History</span>
              </h4>
              <div className="space-y-2">
                {medicalHistory?.map((record, index) => (
                  <div key={index} className="p-3 bg-muted rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{record?.condition}</p>
                        <p className="text-xs text-muted-foreground mt-1">{record?.description}</p>
                      </div>
                      <p className="text-xs text-muted-foreground">{formatDate(record?.date)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Current Medications */}
          {medications?.length > 0 && (
            <div>
              <h4 className="font-medium text-foreground mb-3 flex items-center space-x-2">
                <Icon name="Pill" size={16} className="text-warning" />
                <span>Current Medications</span>
              </h4>
              <div className="space-y-2">
                {medications?.map((medication, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{medication?.name}</p>
                      <p className="text-xs text-muted-foreground">{medication?.dosage}</p>
                    </div>
                    <p className="text-xs text-muted-foreground">{medication?.frequency}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Special Needs */}
          {specialNeeds?.length > 0 && (
            <div>
              <h4 className="font-medium text-foreground mb-3 flex items-center space-x-2">
                <Icon name="AlertTriangle" size={16} className="text-warning" />
                <span>Special Care Requirements</span>
              </h4>
              <div className="space-y-2">
                {specialNeeds?.map((need, index) => (
                  <div key={index} className="p-3 bg-warning/10 border border-warning/20 rounded-lg">
                    <p className="text-sm text-warning font-medium">{need}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Veterinarian Info */}
          {veterinarian && (
            <div>
              <h4 className="font-medium text-foreground mb-3 flex items-center space-x-2">
                <Icon name="Stethoscope" size={16} className="text-primary" />
                <span>Veterinarian</span>
              </h4>
              <div className="p-4 bg-muted rounded-lg">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium">{veterinarian?.name}</p>
                    <p className="text-sm text-muted-foreground">{veterinarian?.clinic}</p>
                    <p className="text-sm text-muted-foreground">{veterinarian?.phone}</p>
                  </div>
                  <Button variant="outline" size="sm" iconName="Phone">
                    Contact
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default HealthRecordsCard;