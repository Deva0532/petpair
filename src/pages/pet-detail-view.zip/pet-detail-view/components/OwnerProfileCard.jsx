import React from 'react';
import { useNavigate } from 'react-router-dom';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const OwnerProfileCard = ({ owner }) => {
  const navigate = useNavigate();

  const {
    id = "owner-1",
    name = "Pet Owner",
    avatar = "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    isVerified = false,
    rating = 0,
    totalReviews = 0,
    memberSince = "2023",
    location = "Unknown Location",
    totalPets = 0,
    responseTime = "Usually responds within 1 hour",
    bio = "Passionate pet owner and breeder."
  } = owner;

  const handleViewProfile = () => {
    navigate('/user-profile-management', { state: { userId: id } });
  };

  const handleMessage = () => {
    navigate('/messaging-center', { state: { recipientId: id, recipientName: name } });
  };

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Icon
        key={index}
        name="Star"
        size={16}
        className={index < rating ? "text-warning fill-current" : "text-muted-foreground"}
      />
    ));
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6 space-y-4">
      {/* Header */}
      <div className="flex items-start space-x-4">
        <div className="relative">
          <Image
            src={avatar}
            alt={`${name}'s profile`}
            className="w-16 h-16 rounded-full object-cover"
          />
          {isVerified && (
            <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-success rounded-full flex items-center justify-center border-2 border-card">
              <Icon name="Check" size={12} className="text-white" />
            </div>
          )}
        </div>
        
        <div className="flex-1">
          <div className="flex items-center space-x-2">
            <h3 className="font-heading font-semibold text-foreground">{name}</h3>
            {isVerified && (
              <Icon name="BadgeCheck" size={18} className="text-success" />
            )}
          </div>
          
          {/* Rating */}
          {rating > 0 && (
            <div className="flex items-center space-x-1 mt-1">
              <div className="flex items-center">
                {renderStars(rating)}
              </div>
              <span className="text-sm text-muted-foreground">
                {rating?.toFixed(1)} ({totalReviews} reviews)
              </span>
            </div>
          )}
          
          <p className="text-sm text-muted-foreground mt-1">{location}</p>
        </div>
      </div>
      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 py-4 border-y border-border">
        <div className="text-center">
          <p className="text-lg font-bold text-foreground">{totalPets}</p>
          <p className="text-xs text-muted-foreground">Pets Listed</p>
        </div>
        <div className="text-center">
          <p className="text-lg font-bold text-foreground">{memberSince}</p>
          <p className="text-xs text-muted-foreground">Member Since</p>
        </div>
      </div>
      {/* Bio */}
      <div>
        <p className="text-sm text-muted-foreground leading-relaxed">{bio}</p>
      </div>
      {/* Response Time */}
      <div className="flex items-center space-x-2 p-3 bg-muted rounded-lg">
        <Icon name="Clock" size={16} className="text-muted-foreground" />
        <p className="text-sm text-muted-foreground">{responseTime}</p>
      </div>
      {/* Action Buttons */}
      <div className="space-y-2">
        <Button
          variant="default"
          fullWidth
          iconName="MessageCircle"
          iconPosition="left"
          onClick={handleMessage}
        >
          Send Message
        </Button>
        
        <Button
          variant="outline"
          fullWidth
          iconName="User"
          iconPosition="left"
          onClick={handleViewProfile}
        >
          View Profile
        </Button>
      </div>
      {/* Trust Indicators */}
      <div className="flex items-center justify-center space-x-4 pt-4 border-t border-border">
        {isVerified && (
          <div className="flex items-center space-x-1 text-success">
            <Icon name="Shield" size={14} />
            <span className="text-xs">Verified Owner</span>
          </div>
        )}
        
        <div className="flex items-center space-x-1 text-muted-foreground">
          <Icon name="MessageCircle" size={14} />
          <span className="text-xs">Quick Response</span>
        </div>
      </div>
    </div>
  );
};

export default OwnerProfileCard;