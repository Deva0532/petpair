import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ImageGallery = ({ images = [], petName = "Pet" }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images?.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images?.length) % images?.length);
  };

  const goToImage = (index) => {
    setCurrentImageIndex(index);
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  if (!images?.length) {
    return (
      <div className="w-full h-80 bg-muted rounded-lg flex items-center justify-center">
        <div className="text-center">
          <Icon name="Image" size={48} className="text-muted-foreground mx-auto mb-2" />
          <p className="text-muted-foreground">No images available</p>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Main Gallery */}
      <div className="relative w-full">
        {/* Main Image */}
        <div className="relative w-full h-80 md:h-96 bg-muted rounded-lg overflow-hidden">
          <Image
            src={images?.[currentImageIndex]}
            alt={`${petName} - Image ${currentImageIndex + 1}`}
            className="w-full h-full object-cover cursor-pointer"
            onClick={toggleFullscreen}
          />
          
          {/* Navigation Arrows */}
          {images?.length > 1 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                iconName="ChevronLeft"
                onClick={prevImage}
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 text-white hover:bg-black/70 w-10 h-10"
              />
              <Button
                variant="ghost"
                size="icon"
                iconName="ChevronRight"
                onClick={nextImage}
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 text-white hover:bg-black/70 w-10 h-10"
              />
            </>
          )}

          {/* Image Counter */}
          <div className="absolute top-4 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
            {currentImageIndex + 1} / {images?.length}
          </div>

          {/* Fullscreen Button */}
          <Button
            variant="ghost"
            size="icon"
            iconName="Maximize"
            onClick={toggleFullscreen}
            className="absolute bottom-4 right-4 bg-black/50 text-white hover:bg-black/70 w-10 h-10"
          />
        </div>

        {/* Thumbnail Navigation */}
        {images?.length > 1 && (
          <div className="flex space-x-2 mt-4 overflow-x-auto pb-2">
            {images?.map((image, index) => (
              <button
                key={index}
                onClick={() => goToImage(index)}
                className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-all ${
                  index === currentImageIndex
                    ? 'border-primary' :'border-transparent hover:border-muted-foreground'
                }`}
              >
                <Image
                  src={image}
                  alt={`${petName} thumbnail ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>
        )}
      </div>
      {/* Fullscreen Modal */}
      {isFullscreen && (
        <div className="fixed inset-0 z-150 bg-black/90 flex items-center justify-center">
          <div className="relative w-full h-full flex items-center justify-center p-4">
            <Image
              src={images?.[currentImageIndex]}
              alt={`${petName} - Fullscreen`}
              className="max-w-full max-h-full object-contain"
            />
            
            {/* Close Button */}
            <Button
              variant="ghost"
              size="icon"
              iconName="X"
              onClick={toggleFullscreen}
              className="absolute top-4 right-4 bg-black/50 text-white hover:bg-black/70 w-12 h-12"
            />

            {/* Navigation in Fullscreen */}
            {images?.length > 1 && (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  iconName="ChevronLeft"
                  onClick={prevImage}
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 text-white hover:bg-black/70 w-12 h-12"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  iconName="ChevronRight"
                  onClick={nextImage}
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 text-white hover:bg-black/70 w-12 h-12"
                />
              </>
            )}

            {/* Image Counter in Fullscreen */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/50 text-white px-4 py-2 rounded-full">
              {currentImageIndex + 1} of {images?.length}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ImageGallery;