import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RelatedPetsCarousel = ({ relatedPets = [] }) => {
  const navigate = useNavigate();
  const [currentIndex, setCurrentIndex] = useState(0);

  const itemsPerView = {
    mobile: 1,
    tablet: 2,
    desktop: 3
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => 
      prev + 1 >= relatedPets?.length - itemsPerView?.desktop + 1 ? 0 : prev + 1
    );
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => 
      prev - 1 < 0 ? Math.max(0, relatedPets?.length - itemsPerView?.desktop) : prev - 1
    );
  };

  const handlePetClick = (petId) => {
    navigate('/pet-detail-view', { state: { petId } });
  };

  if (!relatedPets?.length) {
    return (
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="font-heading font-semibold text-foreground mb-4">Similar Pets</h3>
        <div className="text-center py-8">
          <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-2" />
          <p className="text-muted-foreground">No similar pets found at the moment.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="font-heading font-semibold text-foreground">Similar Pets You Might Like</h3>
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="icon"
            iconName="ChevronLeft"
            onClick={prevSlide}
            disabled={currentIndex === 0}
            className="w-8 h-8"
          />
          <Button
            variant="ghost"
            size="icon"
            iconName="ChevronRight"
            onClick={nextSlide}
            disabled={currentIndex >= relatedPets?.length - itemsPerView?.desktop}
            className="w-8 h-8"
          />
        </div>
      </div>
      {/* Carousel */}
      <div className="relative overflow-hidden">
        <div 
          className="flex transition-transform duration-300 ease-in-out"
          style={{ 
            transform: `translateX(-${currentIndex * (100 / itemsPerView?.desktop)}%)`,
            width: `${(relatedPets?.length / itemsPerView?.desktop) * 100}%`
          }}
        >
          {relatedPets?.map((pet) => (
            <div 
              key={pet?.id} 
              className="flex-shrink-0 px-2"
              style={{ width: `${100 / relatedPets?.length}%` }}
            >
              <PetCard pet={pet} onClick={() => handlePetClick(pet?.id)} />
            </div>
          ))}
        </div>
      </div>
      {/* Dots Indicator */}
      <div className="flex items-center justify-center space-x-2 pt-2">
        {Array.from({ 
          length: Math.ceil(relatedPets?.length / itemsPerView?.desktop) 
        })?.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-2 h-2 rounded-full transition-colors ${
              index === Math.floor(currentIndex / itemsPerView?.desktop)
                ? 'bg-primary' :'bg-muted-foreground'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

const PetCard = ({ pet, onClick }) => {
  const {
    id,
    name = "Unknown Pet",
    breed = "Mixed Breed",
    age = "Unknown",
    price,
    isForBreeding = false,
    breedingFee,
    images = [],
    location = "Unknown Location",
    isFavorited = false
  } = pet;

  const formatPrice = (amount) => {
    if (!amount) return "Contact for price";
    return `$${amount?.toLocaleString()}`;
  };

  const mainImage = images?.[0] || "https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=300&h=200&fit=crop";

  return (
    <div 
      className="bg-card border border-border rounded-lg overflow-hidden cursor-pointer transition-all hover:shadow-elevated hover:scale-105 transform-gpu"
      onClick={onClick}
    >
      {/* Image */}
      <div className="relative h-40 overflow-hidden">
        <Image
          src={mainImage}
          alt={`${name} - ${breed}`}
          className="w-full h-full object-cover"
        />
        
        {/* Favorite Button */}
        <button className="absolute top-2 right-2 w-8 h-8 bg-black/50 rounded-full flex items-center justify-center">
          <Icon 
            name="Heart" 
            size={16} 
            className={isFavorited ? "text-accent fill-current" : "text-white"} 
          />
        </button>

        {/* Type Badge */}
        <div className={`absolute top-2 left-2 px-2 py-1 rounded-full text-xs font-medium ${
          isForBreeding 
            ? 'bg-accent text-white' :'bg-success text-white'
        }`}>
          {isForBreeding ? 'Breeding' : 'Sale'}
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-2">
        <div>
          <h4 className="font-medium text-foreground truncate">{name}</h4>
          <p className="text-sm text-muted-foreground truncate">{breed}</p>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-1">
            <Icon name="MapPin" size={12} className="text-muted-foreground" />
            <span className="text-xs text-muted-foreground truncate">{location}</span>
          </div>
          <span className="text-xs text-muted-foreground">{age}</span>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-border">
          <span className="font-bold text-primary">
            {formatPrice(isForBreeding ? breedingFee : price)}
          </span>
          <Button variant="ghost" size="sm" iconName="ArrowRight" className="text-muted-foreground">
            View
          </Button>
        </div>
      </div>
    </div>
  );
};

export default RelatedPetsCarousel;