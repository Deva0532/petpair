import React from 'react';
import Icon from '../../../components/AppIcon';

const PetInfoCard = ({ pet }) => {
  const {
    name = "Unknown",
    breed = "Mixed Breed",
    age = "Unknown",
    gender = "Unknown",
    size = "Unknown",
    weight = "Unknown",
    color = "Unknown",
    location = "Unknown",
    price,
    isForBreeding = false,
    breedingFee,
    description = "No description available.",
    traits = [],
    healthStatus = "Unknown"
  } = pet;

  const formatPrice = (amount) => {
    if (!amount) return "Contact for price";
    return `$${amount?.toLocaleString()}`;
  };

  const getGenderIcon = (gender) => {
    switch (gender?.toLowerCase()) {
      case 'male':
        return 'Mars';
      case 'female':
        return 'Venus';
      default:
        return 'HelpCircle';
    }
  };

  const getSizeIcon = (size) => {
    switch (size?.toLowerCase()) {
      case 'small':
        return 'Circle';
      case 'medium':
        return 'CircleDot';
      case 'large':
        return 'CircleDotDashed';
      default:
        return 'Circle';
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-heading font-bold text-foreground">{name}</h1>
          <p className="text-lg text-muted-foreground">{breed}</p>
        </div>
        <div className="text-right">
          {isForBreeding ? (
            <div>
              <p className="text-sm text-muted-foreground">Breeding Fee</p>
              <p className="text-xl font-bold text-primary">{formatPrice(breedingFee)}</p>
            </div>
          ) : (
            <div>
              <p className="text-sm text-muted-foreground">Price</p>
              <p className="text-xl font-bold text-primary">{formatPrice(price)}</p>
            </div>
          )}
        </div>
      </div>
      {/* Basic Info Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="flex items-center space-x-2">
          <Icon name="Calendar" size={18} className="text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground">Age</p>
            <p className="font-medium">{age}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Icon name={getGenderIcon(gender)} size={18} className="text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground">Gender</p>
            <p className="font-medium capitalize">{gender}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Icon name={getSizeIcon(size)} size={18} className="text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground">Size</p>
            <p className="font-medium capitalize">{size}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Icon name="Weight" size={18} className="text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground">Weight</p>
            <p className="font-medium">{weight}</p>
          </div>
        </div>
      </div>
      {/* Additional Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="flex items-center space-x-2">
          <Icon name="Palette" size={18} className="text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground">Color</p>
            <p className="font-medium">{color}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Icon name="MapPin" size={18} className="text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground">Location</p>
            <p className="font-medium">{location}</p>
          </div>
        </div>
      </div>
      {/* Health Status */}
      <div className="flex items-center space-x-2 p-3 bg-muted rounded-lg">
        <Icon name="Heart" size={18} className="text-success" />
        <div>
          <p className="text-xs text-muted-foreground">Health Status</p>
          <p className="font-medium text-success">{healthStatus}</p>
        </div>
      </div>
      {/* Description */}
      <div>
        <h3 className="font-heading font-semibold text-foreground mb-2">About {name}</h3>
        <p className="text-muted-foreground leading-relaxed">{description}</p>
      </div>
      {/* Traits */}
      {traits?.length > 0 && (
        <div>
          <h3 className="font-heading font-semibold text-foreground mb-3">Personality & Traits</h3>
          <div className="flex flex-wrap gap-2">
            {traits?.map((trait, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full border border-primary/20"
              >
                {trait}
              </span>
            ))}
          </div>
        </div>
      )}
      {/* Breeding/Sale Type Badge */}
      <div className="flex items-center justify-center pt-4 border-t border-border">
        <div className={`flex items-center space-x-2 px-4 py-2 rounded-full ${
          isForBreeding 
            ? 'bg-accent/10 text-accent border border-accent/20' :'bg-success/10 text-success border border-success/20'
        }`}>
          <Icon name={isForBreeding ? "Heart" : "ShoppingBag"} size={16} />
          <span className="font-medium">
            {isForBreeding ? "Available for Breeding" : "Available for Sale"}
          </span>
        </div>
      </div>
    </div>
  );
};

export default PetInfoCard;