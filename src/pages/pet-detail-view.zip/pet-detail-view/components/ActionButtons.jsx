import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const ActionButtons = ({ petId, isFavorited = false, onFavoriteToggle }) => {
  const navigate = useNavigate();
  const [isSharing, setIsSharing] = useState(false);
  const [showReportMenu, setShowReportMenu] = useState(false);

  const handleMessage = () => {
    navigate('/messaging-center', { 
      state: { 
        petId,
        context: 'pet-inquiry'
      } 
    });
  };

  const handleFavoriteToggle = () => {
    if (onFavoriteToggle) {
      onFavoriteToggle();
    }
  };

  const handleShare = async () => {
    setIsSharing(true);
    
    try {
      if (navigator.share) {
        await navigator.share({
          title: 'Check out this pet on PetPair',
          text: 'I found this amazing pet on PetPair!',
          url: window.location?.href,
        });
      } else {
        // Fallback: Copy to clipboard
        await navigator.clipboard?.writeText(window.location?.href);
        // You could show a toast notification here
        alert('Link copied to clipboard!');
      }
    } catch (error) {
      console.error('Error sharing:', error);
    } finally {
      setIsSharing(false);
    }
  };

  const handleReport = () => {
    setShowReportMenu(!showReportMenu);
  };

  const handleReportSubmit = (reason) => {
    // Handle report submission
    console.log('Reporting pet for:', reason);
    setShowReportMenu(false);
    alert('Thank you for your report. We will review this listing.');
  };

  const reportReasons = [
    'Inappropriate content',
    'Suspected scam',
    'Animal welfare concern',
    'Duplicate listing',
    'Incorrect information',
    'Other'
  ];

  return (
    <>
      {/* Mobile Sticky Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-140 bg-card border-t border-border md:hidden safe-area-pb">
        <div className="flex items-center justify-between px-4 py-3 space-x-3">
          <Button
            variant="ghost"
            size="icon"
            iconName={isFavorited ? "Heart" : "Heart"}
            onClick={handleFavoriteToggle}
            className={`${isFavorited ? "text-accent" : "text-muted-foreground"} flex-shrink-0`}
          />
          
          <Button
            variant="default"
            fullWidth
            iconName="MessageCircle"
            iconPosition="left"
            onClick={handleMessage}
            className="flex-1"
          >
            Contact Owner
          </Button>
          
          <div className="relative flex-shrink-0">
            <Button
              variant="ghost"
              size="icon"
              iconName="MoreVertical"
              onClick={handleReport}
              className="text-muted-foreground"
            />
            
            {showReportMenu && (
              <div className="absolute bottom-full right-0 mb-2 w-48 bg-popover border border-border rounded-lg shadow-elevated z-150">
                <div className="py-2">
                  <button
                    onClick={handleShare}
                    disabled={isSharing}
                    className="flex items-center space-x-2 w-full px-4 py-2 text-sm text-popover-foreground hover:bg-muted transition-quick"
                  >
                    <Icon name="Share" size={16} />
                    <span>{isSharing ? 'Sharing...' : 'Share'}</span>
                  </button>
                  
                  <div className="border-t border-border my-1" />
                  
                  <div className="px-4 py-2">
                    <p className="text-xs text-muted-foreground mb-2">Report this listing:</p>
                    {reportReasons?.map((reason) => (
                      <button
                        key={reason}
                        onClick={() => handleReportSubmit(reason)}
                        className="block w-full text-left px-2 py-1 text-xs text-error hover:bg-error/10 rounded transition-quick"
                      >
                        {reason}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      {/* Desktop Action Buttons */}
      <div className="hidden md:flex items-center justify-center space-x-4 py-6">
        <Button
          variant="ghost"
          size="lg"
          iconName={isFavorited ? "Heart" : "Heart"}
          iconPosition="left"
          onClick={handleFavoriteToggle}
          className={isFavorited ? "text-accent" : "text-muted-foreground"}
        >
          {isFavorited ? "Remove from Favorites" : "Add to Favorites"}
        </Button>
        
        <Button
          variant="default"
          size="lg"
          iconName="MessageCircle"
          iconPosition="left"
          onClick={handleMessage}
        >
          Contact Owner
        </Button>
        
        <Button
          variant="ghost"
          size="lg"
          iconName="Share"
          iconPosition="left"
          onClick={handleShare}
          disabled={isSharing}
          className="text-muted-foreground"
        >
          {isSharing ? 'Sharing...' : 'Share'}
        </Button>

        <div className="relative">
          <Button
            variant="ghost"
            size="lg"
            iconName="Flag"
            iconPosition="left"
            onClick={handleReport}
            className="text-muted-foreground"
          >
            Report
          </Button>
          
          {showReportMenu && (
            <div className="absolute top-full left-0 mt-2 w-56 bg-popover border border-border rounded-lg shadow-elevated z-140">
              <div className="py-2">
                <div className="px-4 py-2 border-b border-border">
                  <p className="text-sm font-medium text-popover-foreground">Report this listing</p>
                  <p className="text-xs text-muted-foreground">Help us keep PetPair safe</p>
                </div>
                
                <div className="py-2">
                  {reportReasons?.map((reason) => (
                    <button
                      key={reason}
                      onClick={() => handleReportSubmit(reason)}
                      className="flex items-center space-x-2 w-full px-4 py-2 text-sm text-error hover:bg-error/10 transition-quick"
                    >
                      <Icon name="Flag" size={14} />
                      <span>{reason}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default ActionButtons;