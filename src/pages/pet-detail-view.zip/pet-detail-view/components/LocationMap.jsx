import React from 'react';
import Icon from '../../../components/AppIcon';

const LocationMap = ({ location = {} }) => {
  const {
    city = "Unknown City",
    state = "Unknown State",
    zipCode = "00000",
    latitude = 40.7128,
    longitude = -74.0060,
    showExactLocation = false
  } = location;

  const mapSrc = `https://www.google.com/maps?q=${latitude},${longitude}&z=14&output=embed`;

  return (
    <div className="bg-card rounded-lg border border-border p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center space-x-2">
        <Icon name="MapPin" size={20} className="text-accent" />
        <h3 className="font-heading font-semibold text-foreground">Location</h3>
      </div>

      {/* Location Info */}
      <div className="flex items-start space-x-3">
        <Icon name="MapPin" size={18} className="text-muted-foreground mt-1" />
        <div>
          <p className="font-medium text-foreground">
            {showExactLocation ? `${city}, ${state} ${zipCode}` : `${city}, ${state}`}
          </p>
          <p className="text-sm text-muted-foreground">
            {showExactLocation 
              ? "Exact location shown" :"General area shown for privacy"
            }
          </p>
        </div>
      </div>

      {/* Map Container */}
      <div className="w-full h-64 rounded-lg overflow-hidden border border-border">
        <iframe
          width="100%"
          height="100%"
          loading="lazy"
          title={`${city}, ${state} Location`}
          referrerPolicy="no-referrer-when-downgrade"
          src={mapSrc}
          className="border-0"
        />
      </div>

      {/* Privacy Notice */}
      <div className="flex items-start space-x-2 p-3 bg-muted rounded-lg">
        <Icon name="Shield" size={16} className="text-muted-foreground mt-0.5" />
        <div>
          <p className="text-sm text-muted-foreground">
            <strong>Privacy Protected:</strong> Exact address is only shared after initial contact 
            to ensure the safety of both pets and owners.
          </p>
        </div>
      </div>

      {/* Distance Info */}
      <div className="flex items-center justify-between pt-2 border-t border-border">
        <div className="flex items-center space-x-2">
          <Icon name="Navigation" size={16} className="text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Distance from you</span>
        </div>
        <span className="text-sm font-medium text-foreground">~12 miles</span>
      </div>
    </div>
  );
};

export default LocationMap;